# DAEJUNG_NEXT_00_ALL_INTEGRATED_PREVIEW

## 설명
위 기능들을 한 번에 확인하는 통합 미리보기

## 적용
압축을 풀고 기존 Vite React 프로젝트에 같은 경로 기준으로 덮어쓰기 하세요.

## 실행
npm install
npm run dev

## 권장 순서
01_CORE_BRIDGE → 02_CUSTOMER_AI_PACK → 03_DEFENSE_RISK_PACK → 04_AUTO_EVOLUTION_PACK → 05_AI_CHARACTER_LIVE_PACK

통합 확인은 00_ALL_INTEGRATED_PREVIEW 사용.
