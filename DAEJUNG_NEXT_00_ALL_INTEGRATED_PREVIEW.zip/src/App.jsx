
import {useState} from "react";
import CustomerAIPack from "./components/CustomerAIPack.jsx";
import DefenseRiskPack from "./components/DefenseRiskPack.jsx";
import AutoEvolutionPack from "./components/AutoEvolutionPack.jsx";
import CharacterLivePack from "./components/CharacterLivePack.jsx";
export default function App(){
 const [tab,setTab]=useState("customer");
 const map={customer:<CustomerAIPack/>,defense:<DefenseRiskPack/>,auto:<AutoEvolutionPack/>,character:<CharacterLivePack/>};
 return <div className="app-shell"><header className="top-nav"><div><strong>DAEJUNG NEXT</strong><span>All Integrated Upgrade Preview</span></div></header>
 <div className="nav-tabs"><button onClick={()=>setTab("customer")}>고객AI</button><button onClick={()=>setTab("defense")}>기업방어</button><button onClick={()=>setTab("auto")}>자동진화</button><button onClick={()=>setTab("character")}>AI쇼호스트</button></div>
 {map[tab]}<div className="footer-note">이 통합 미리보기는 분리팩을 한 화면에서 확인하기 위한 버전입니다. 실제 적용은 01~05 순서 권장.</div></div>
}
