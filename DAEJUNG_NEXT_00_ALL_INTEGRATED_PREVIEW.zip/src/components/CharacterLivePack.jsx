
import {useMemo,useState} from "react";
const tone={
"10대":"짧고 재미있게, 코인 미션 중심으로 안내할게요!",
"20대":"트렌드·리뷰·가격혜택 중심으로 빠르게 추천할게요.",
"30대":"가성비, 가족소비, 정기구매 혜택을 우선 안내하겠습니다.",
"40대":"품질, 신뢰, 상세 설명을 중심으로 차분히 안내하겠습니다.",
"50대":"홈쇼핑처럼 쉽고 친절하게 핵심 혜택을 설명드리겠습니다.",
"60대":"큰 글씨, 쉬운 설명, 상담 연결 중심으로 도와드리겠습니다.",
"70대":"복잡한 절차 없이 상담과 가족공유를 먼저 안내하겠습니다."
};
export default function CharacterLivePack(){
 const [age,setAge]=useState("40대"); const [emotion,setEmotion]=useState("관심"); const [chat,setChat]=useState("");
 const buy=useMemo(()=> emotion==="긍정"?86:emotion==="관심"?72:emotion==="망설임"?54:38,[emotion]);
 const script=`${tone[age]} 현재 고객 반응은 '${emotion}' 상태입니다. 구매 가능성은 ${buy}점으로 판단됩니다.`;
 return <section className="panel"><div className="header-row"><div><span className="badge">AI CHARACTER LIVE PACK</span><h1>AI 쇼호스트 · 감정반응 · 캐릭터 운영</h1><p>연령별 말투, LIVE 반응, 구매 가능성, 상담 전환을 캐릭터 쇼호스트가 자동 판단합니다.</p></div><div className="score-box"><span>구매가능성</span><strong>{buy}</strong><small>{emotion} 반응</small></div></div>
 <div className="row"><select value={age} onChange={e=>setAge(e.target.value)}>{Object.keys(tone).map(a=><option key={a}>{a}</option>)}</select><select value={emotion} onChange={e=>setEmotion(e.target.value)}>{["긍정","관심","망설임","부정"].map(e=><option key={e}>{e}</option>)}</select><input className="wide-input" value={chat} onChange={e=>setChat(e.target.value)} placeholder="LIVE 채팅/고객반응 입력"/></div>
 <div className="grid-3" style={{marginTop:20}}><article className="card"><b>AI 멘트</b><h3>{script}</h3></article><article className="card"><b>자동 행동</b><h3>{buy>=80?"즉시 구매버튼·한정혜택 노출":buy>=60?"쿠폰·상담형 추천 노출":"상담모드/쉬운 설명 전환"}</h3></article><article className="card"><b>고객 채팅 분석</b><h3>{chat?`"${chat}" 반응을 분석해 다음 추천에 반영`:"채팅 입력 대기중"}</h3></article></div>
 </section>
}
