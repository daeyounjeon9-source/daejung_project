
import {useMemo,useState} from "react";
const ages=["10대","20대","30대","40대","50대","60대","70대"];
const base={ "10대":58,"20대":72,"30대":81,"40대":86,"50대":89,"60대":76,"70대":63 };
const tendency={
"10대":"숏폼·캐릭터·즉시보상·친구공유 반응",
"20대":"가격·트렌드·리뷰·빠른 모바일 경험",
"30대":"가성비·가족소비·생활필수품·정기구매",
"40대":"품질·신뢰·건강·상세 설명",
"50대":"홈쇼핑 친화·건강/식품/가전·상담 신뢰",
"60대":"편의성·전화상담·건강식품·큰 버튼",
"70대":"초간단 구매·가족 추천·음성안내·상담 중심"
};
export default function CustomerAIPack(){
 const [search,setSearch]=useState(""); const [logs,setLogs]=useState([]);
 const [scores,setScores]=useState(base);
 const rec=useMemo(()=>Object.entries(scores).sort((a,b)=>b[1]-a[1]),[scores]);
 const apply=(age,act)=>{setScores(s=>({...s,[age]:Math.min(100,s[age]+(act==="구매"?12:act==="상담"?8:act==="라이브"?6:3))}));setLogs(l=>[{age,act,time:new Date().toLocaleTimeString()},...l].slice(0,8));}
 const searchApply=()=>{if(!search.trim())return; apply("40대","검색"); setSearch("");}
 return <section className="panel">
  <div className="header-row"><div><span className="badge">CUSTOMER AI PACK</span><h1>고객기억 AI · 연령별 수요예측</h1><p>검색·조회·라이브·상담·구매 반응을 실증데이터로 누적해 재접속 추천과 연령별 전략을 자동 보정합니다.</p></div><div className="score-box"><span>최고 수요</span><strong>{rec[0][0]}</strong><small>{rec[0][1]}점</small></div></div>
  <div className="row"><input className="wide-input" value={search} onChange={e=>setSearch(e.target.value)} placeholder="검색어 예: 홍삼, 운동화, 쌀"/><button onClick={searchApply}>검색기록 반영</button></div>
  <div className="grid-3" style={{marginTop:20}}>{ages.map(age=><article className="card" key={age}><div className="risk-top"><span>{age}</span><b>{scores[age]}점</b></div><h3>{tendency[age]}</h3><p>접속유도: 맞춤 LIVE, 쿠폰, 코인혜택, 연령별 설명모드</p><div className="row"><button onClick={()=>apply(age,"라이브")}>라이브</button><button onClick={()=>apply(age,"상담")}>상담</button><button onClick={()=>apply(age,"구매")}>구매</button></div></article>)}</div>
  <div className="panel log"><span className="badge">Evidence Log</span><h2>실증데이터 확보 기록</h2>{logs.length?logs.map((l,i)=><div key={i}><b>{l.age} {l.act}</b><span>{l.time} 반영 완료</span></div>):<p>아직 기록 없음</p>}</div>
 </section>
}
