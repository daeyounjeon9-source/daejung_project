# DAEJUNG_NEXT_01_CORE_BRIDGE

## 설명
기존 대정넥스트에 기능팩을 연결하는 공통 브릿지/메뉴/레이아웃

## 적용
압축을 풀고 기존 Vite React 프로젝트에 같은 경로 기준으로 덮어쓰기 하세요.

## 실행
npm install
npm run dev

## 권장 순서
01_CORE_BRIDGE → 02_CUSTOMER_AI_PACK → 03_DEFENSE_RISK_PACK → 04_AUTO_EVOLUTION_PACK → 05_AI_CHARACTER_LIVE_PACK

통합 확인은 00_ALL_INTEGRATED_PREVIEW 사용.
