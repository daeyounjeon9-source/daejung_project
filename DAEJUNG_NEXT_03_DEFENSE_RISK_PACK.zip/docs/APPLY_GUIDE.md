# DAEJUNG_NEXT_03_DEFENSE_RISK_PACK

## 설명
기업성장 방해요소 + 공격대응 + 규제/주식변동 방어

## 적용
압축을 풀고 기존 Vite React 프로젝트에 같은 경로 기준으로 덮어쓰기 하세요.

## 실행
npm install
npm run dev

## 권장 순서
01_CORE_BRIDGE → 02_CUSTOMER_AI_PACK → 03_DEFENSE_RISK_PACK → 04_AUTO_EVOLUTION_PACK → 05_AI_CHARACTER_LIVE_PACK

통합 확인은 00_ALL_INTEGRATED_PREVIEW 사용.
