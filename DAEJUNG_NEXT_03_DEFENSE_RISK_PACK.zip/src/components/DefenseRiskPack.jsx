
import {useState} from "react";
const start=[
["가격경쟁","주의","대기업·중국계 플랫폼 초저가 공세","AI추천+LIVE+코인경제로 가격 외 차별화",78],
["여론공격","위험","허위 리뷰·커뮤니티 악성 이슈","실구매 인증·이상리뷰 탐지·법무대응 로그",91],
["주식변동","주의","상장 후 뉴스/세력 움직임 급등락","실적·실사용자·실증데이터 중심 IR",83],
["인프라","위험","라이브 폭주·동시접속 서버 병목","CDN·트래픽 분산·실시간 모니터링",94],
["규제리스크","위험","코인/포인트 정책 규제 변화","법무·세무·회계 분리 및 보상형 정책",96],
["경쟁사모방","주의","대기업 유사 기능 모방","고객기억AI+실증데이터+캐릭터 통합 방어",80]
];
export default function DefenseRiskPack(){
 const [items,setItems]=useState(start.map((x,i)=>({id:i,cat:x[0],lv:x[1],th:x[2],res:x[3],score:x[4],done:false})));
 const [custom,setCustom]=useState("");
 const unresolved=items.filter(i=>!i.done); const score=Math.max(10,100-Math.round(unresolved.reduce((a,b)=>a+b.score,0)/10));
 const add=()=>{if(!custom.trim())return; setItems([{id:Date.now(),cat:"사용자지정",lv:"주의",th:custom,res:"관리자 검토·실증데이터 확보·법무/운영 반영",score:72,done:false},...items]);setCustom("");}
 return <section className="panel"><div className="header-row"><div><span className="badge danger-badge">DEFENSE & RISK PACK</span><h1>기업방어 · 공격대응 · 주식변동 예측</h1><p>기업성장 방해요소, 여론공격, 경쟁사 추격, 규제/코인/서버/주식변동 리스크를 선제 대응합니다.</p></div><div className="score-box"><span>기업방어 점수</span><strong>{score}</strong><small>미조치 {unresolved.length}개</small></div></div>
 <div className="row"><input className="wide-input" value={custom} onChange={e=>setCustom(e.target.value)} placeholder="추가 위협 입력"/><button onClick={add}>위협 추가</button></div>
 <div className="grid-3" style={{marginTop:20}}>{items.map(it=><article key={it.id} className={"card "+(it.lv==="위험"?"danger-card ":"")+(it.done?"resolved-card":"")}><div className="risk-top"><span>{it.cat}</span><b>{it.done?"대응완료":it.lv}</b></div><h3>{it.th}</h3><dl><dt>대응방향</dt><dd>{it.res}</dd></dl><div className="risk-bottom"><small>위험도 {it.score}</small><button onClick={()=>setItems(items.map(x=>x.id===it.id?{...x,done:!x.done}:x))}>{it.done?"재점검":"대응완료"}</button></div></article>)}</div></section>
}
