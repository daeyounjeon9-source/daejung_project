
import {useState} from "react";
export default function AutoEvolutionPack(){
 const [m,setM]=useState({visitors:18420,conversion:2.8,live:61,repeat:38,coupon:47,server:54});
 const [actions,setActions]=useState([{t:"20대 검색 증가",d:"숏폼 LIVE 및 타임특가 상단 배치",c:84},{t:"40~50대 건강식품 체류 증가",d:"상담형 LIVE와 건강 추천 우선노출",c:91},{t:"LIVE 시청 대비 결제 감소",d:"즉시쿠폰·코인보상 자동 활성화",c:87}]);
 const score=Math.max(10,Math.min(99,Math.round(m.conversion*10+m.live*.4+m.repeat*.5+m.coupon*.2)));
 const run=()=>{const n={visitors:m.visitors+Math.floor(Math.random()*1000),conversion:+(m.conversion+(Math.random()*.5-.2)).toFixed(1),live:Math.min(99,m.live+Math.floor(Math.random()*6-2)),repeat:Math.min(99,m.repeat+Math.floor(Math.random()*5)),coupon:Math.min(99,m.coupon+Math.floor(Math.random()*4)),server:Math.min(99,m.server+Math.floor(Math.random()*8-3))};setM(n); const gen=[]; if(n.conversion<3)gen.push({t:"구매전환 하락 감지",d:"AI 할인전략 및 추천 알고리즘 강화",c:86}); if(n.live>65)gen.push({t:"LIVE 체류시간 증가",d:"관련 상품 자동 추천 확대",c:89}); if(n.server>70)gen.push({t:"서버 부하 증가",d:"트래픽 분산 및 캐시 최적화",c:94}); setActions([...gen,...actions].slice(0,10));}
 return <section className="panel"><div className="header-row"><div><span className="badge">AUTO EVOLUTION PACK</span><h1>AI 자동 전략 수정 엔진</h1><p>매출·검색·이탈·LIVE·서버 변화를 감지해 메인화면, 추천, 쿠폰, LIVE 전략을 자동 조정합니다.</p></div><div className="score-box"><span>AI 진화 점수</span><strong>{score}</strong><small>자동 전략 적용중</small></div></div>
 <div className="grid-6" style={{marginTop:20}}>{[["방문자",m.visitors.toLocaleString()],["구매전환율",m.conversion+"%"],["LIVE유지율",m.live+"%"],["재방문율",m.repeat+"%"],["쿠폰사용률",m.coupon+"%"],["서버부하",m.server+"%"]].map(([a,b])=><article className="card" key={a}><b>{a}</b><strong>{b}</strong></article>)}</div>
 <div style={{marginTop:20}}><button onClick={run}>AI 자동 전략 재학습 실행</button></div>
 <div className="grid-3" style={{marginTop:20}}>{actions.map((a,i)=><article className="card" key={i}><div className="risk-top"><span>AI 자동판단</span><b>{a.c}%</b></div><h3>{a.t}</h3><p>{a.d}</p></article>)}</div></section>
}
